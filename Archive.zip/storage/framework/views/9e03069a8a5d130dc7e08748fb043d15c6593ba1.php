<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script> 

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com"> 
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    
    <link rel="stylesheet" href="<?php echo e(asset('css/toastr.min.css')); ?>">    
</head>
<body>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
            <div class="container">
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>"> </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">

                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->
                    </ul>
                </div>
            </div>
        </nav>

        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>

    <script src="<?php echo e(asset('js/jquery-3.4.1.min.js')); ?>"></script>      
    <script src="<?php echo e(asset('js/toastr.min.js')); ?>"></script>   
    <script src="<?php echo e(asset('wp/js/sweetalert.min.js')); ?>"></script>     

<script>  
        <?php if(Session::has('message')): ?> 
            var type = "<?php echo e(Session::get('alert-type', 'info')); ?>"; 
            switch (type) {
                case 'info' :
                    toastr.info("<?php echo e(Session::get('message')); ?>");
                    break; 
                case 'success' :
                    toastr.success("<?php echo e(Session::get('message')); ?>");
                    break; 
                case 'warning' :
                    toastr.warning("<?php echo e(Session::get('message')); ?>");
                    break; 
                case 'error' :
                    toastr.error("<?php echo e(Session::get('message')); ?>");
                    break;  
            }
        <?php endif; ?>
    </script>  

    <?php echo $__env->yieldContent('extjs'); ?>  

</body>
</html>
<?php /**PATH /Users/duytu/dev/dev_home/payment_visa/resources/views/layouts/app.blade.php ENDPATH**/ ?>