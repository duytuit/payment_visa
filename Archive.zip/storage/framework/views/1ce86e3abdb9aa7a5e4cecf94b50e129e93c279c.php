 <!-- Left side column. contains the logo and sidebar -->
 <aside class="main-sidebar">

<!-- sidebar: style can be found in sidebar.less -->
<section class="sidebar">

  <!-- Sidebar user panel (optional) -->
  <div class="user-panel">
    <div class="pull-left image">
      <img src="<?php echo e(asset('storage/'.Auth::user()->image)); ?>" class="img-circle" alt="User Image">
    </div>
    <div class="pull-left info">
      <p><?php echo e(Auth::user()->name); ?></p> 
      <!-- Status -->
    <a href="javascript:void(0);"><i class="fa fa-circle text-success"></i> Online</a>
    </div>
  </div>  

  <!-- search form (Optional) -->
  <!-- /.search form -->

  <!-- Sidebar Menu -->
  <ul class="sidebar-menu" data-widget="tree">  
    <li class="header">HEADER</li> 
    <!-- Optionally, you can add icons to the links -->
    
    <li>
      <a href="<?php echo e(route('dashboard')); ?>"><i class="fa fa-tachometer"></i> 
        <span>Dashboard</span>  
      </a>
    </li>
 
    <li class="<?php echo e((request()->is('users*')) ? 'active' : ''); ?>">  
      <a href="<?php echo e(route('users.index')); ?>"> 
        <i class="fa fa-users"></i> 
        <span>Users</span>     
      </a>
    </li> 
    
    <li class="<?php echo e((request()->is('permission.index')) ? 'active' : ''); ?>">
      <a href="<?php echo e(route('permission.index')); ?>"><i class="fa fa-lock"></i> 
        <span>Permissions</span>  
      </a>
    </li>    

    <li class="<?php echo e((request()->is('role.index')) ? 'active' : ''); ?>">
      <a href="<?php echo e(route('role.index')); ?>"><i class="fa fa-shield"></i> 
        <span>Roles</span>  
      </a>
    </li>   

    <li class="<?php echo e((request()->is('media')) ? 'active' : ''); ?>">
      <a href="<?php echo e(route('media')); ?>"><i class="fa fa-camera"></i>  
        <span>Media</span>  
      </a>
    </li>  

    <li class="<?php echo e((request()->is('info-visa')) ? 'active' : ''); ?>">
      <a href="<?php echo e(route('info_visa.list')); ?>"><i class="fa fa-users"></i>  
        <span>InfoVisa</span>  
      </a>
    </li>  

    <li class="treeview"> 
        <a href="#">
          <i class="fa fa-list"></i> 
          <span>Categories</span>   
          <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
          </span> 
        </a>
        <ul class="treeview-menu"> 
            <li>
            <a href="<?php echo e(route('category.index')); ?>">All Categories</a>  
            </li>       
        </ul> 
    </li>    

    <li class="treeview"> 
        <a href="#">
          <i class="fa fa-shopping-bag"></i> 
          <span>Products</span>   
          <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
          </span> 
        </a>
        <ul class="treeview-menu"> 
          <li><a href="<?php echo e(route('product.index')); ?>">Products</a></li>           
          <li><a href="<?php echo e(route('attribute.index')); ?>">Attributes</a></li>                      
          <li><a href="<?php echo e(route('tax.index')); ?>">Tax</a></li>                      
        </ul> 
    </li> 
   
    <li class="treeview">  
        <a href="#">
          <i class="fa fa-cog"></i> 
          <span>Settings</span>
          <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
          </span> 
        </a>
        <ul class="treeview-menu"> 
            <li><a href="<?php echo e(route('menu.index')); ?>">Menu Builder</a></li>       
            <li><a href="<?php echo e(route('social.index')); ?>">Social Profiles</a></li>        
        </ul> 
    </li> 

    <li class="header">Reports</li>  
  </ul>
  <!-- /.sidebar-menu --> 
</section>
<!-- /.sidebar -->
</aside><?php /**PATH /Users/duytu/dev/dev_home/payment_visa/resources/views/admin/layouts/sidebar.blade.php ENDPATH**/ ?>