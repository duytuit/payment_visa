<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
                Permissions
                <small>List</small>
            </h1>
            <ol class="breadcrumb">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permission-write')): ?>
                    <li><a href="<?php echo e(route('permission.index')); ?>"><i class="fa fa-users"></i>Permissions</a></li>
                <?php endif; ?>

                <li class="active">Permissions List</li>
            </ol>
        </section>

        <!-- Main content -->
        <section class="content container-fluid">

            <!--------------------------
            | Your Page Content Here |
            -------------------------->
            <div class="box">
                <div class="box-header">
                    <h3 class="box-title" style="display:block">Manage Permissions
                        <span class="pull-right" style="display:inline-block">
                            <a class="btn btn-primary btn-sm" href="<?php echo e(route('permission.create')); ?>"> <i
                                    class="fa fa-plus"></i> Add New</a>
                        </span>
                    </h3>
                </div>
                <!-- /.box-header -->
                <div class="box-body">
                    <table class="datatable table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Name</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permission-read')): ?>
                                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->index + 1); ?></td>
                                        <td><?php echo e(ucwords($permission->name)); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="8">
                                        <h3 class="text-danger">Oops! You have no permission for this action!</h3>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>

                        <tfoot>
                            <tr>
                                <th>#</th>
                                <th>Name</th>
                            </tr>
                        </tfoot>
                    </table>
                    <div class="row mbm">
                        <div class="col-sm-3">
                            <span class="record-total" style="text-align: right;">Tổng: <?php echo e($permissions->total()); ?> bản
                                ghi</span>
                        </div>
                        <div class="col-sm-6 text-center">
                            <div class="pagination-panel">
                                <?php echo e($permissions->appends(Request::all())->onEachSide(1)->links()); ?>

                            </div>
                        </div>
                        <div class="col-sm-3 text-right">
                            <span class="form-inline">
                                Hiển thị
                                <select name="per_page" class="form-control" data-target="#form-service-apartment">
                                    <?php $list = [10, 20, 50, 100, 200]; ?>
                                    <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $num): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($num); ?>" <?php echo e($num == @$per_page ? 'selected' : ''); ?>>
                                            <?php echo e($num); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </span>
                        </div>
                    </div>
                </div>
                <!-- /.box-body -->
            </div>
            <!-- /.box -->

        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', 'Manage Permissions'); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/duytu/dev/dev_home/payment_visa/resources/views/admin/permissions/index.blade.php ENDPATH**/ ?>