<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                   <p class="alert alert-danger">Access Denied! You have no permission for this action.</p>
                   <a href="<?php echo e(url('/')); ?>">Back</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/duytu/dev/dev_home/payment_visa/resources/views/nopermission.blade.php ENDPATH**/ ?>