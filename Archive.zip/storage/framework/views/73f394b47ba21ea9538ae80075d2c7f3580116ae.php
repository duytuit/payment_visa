 

<?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Tax
        <small>List</small>
      </h1>
      <ol class="breadcrumb">
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permission-write')): ?>
      <li><a href="<?php echo e(route('tax.index')); ?>"><i class="fa fa-users"></i>Taxes</a></li>
      <?php endif; ?>

      <li class="active">Manage Taxes</li>  
      </ol>
    </section> 

    <!-- Main content -->
    <section class="content container-fluid">    

      <!--------------------------
        | Your Page Content Here |
        -------------------------->
        <div class="box">
                <div class="box-header">
                  <h3 class="box-title" style="display:block">Manage Taxes
                      <span class="pull-right" style="display:inline-block">
                      <a class="btn btn-primary btn-sm" href="<?php echo e(route('tax.create')); ?>"> <i class="fa fa-plus"></i> Add New</a>
                      </span> 
                  </h3>
                </div>
                <!-- /.box-header -->
                <div class="box-body">
                  <table class="datatable table table-bordered table-responsive table-striped">
                    <thead>
                    <tr>
                      <th>#</th>
                      <th>Tax Class</th> 
                      <th>Name</th> 
                      <th>Country</th> 
                      <th>State</th> 
                      <th>City</th>
                      <th>Zip</th> 
                      <th>Rate</th> 
                      <th>Based On</th> 
                      <th>Active</th> 
                      <th>Actions</th> 
                    </tr>
                    </thead>

                    <tbody>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('category-read')): ?>
                    <?php $__currentLoopData = $taxes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tax): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    <tr>
                      <td><?php echo e($loop->index + 1); ?></td>
                      <td><?php echo e($tax->tax_class); ?></td>  
                      <td><?php echo e($tax->name); ?></td>  
                      <td><?php echo e($tax->country); ?></td>  
                      <td><?php echo e($tax->state); ?></td>  
                      <td><?php echo e($tax->city); ?></td>  
                      <td><?php echo e($tax->zip); ?></td>  
                      <td><?php echo e($tax->rate); ?></td>  
                      <td><?php echo e($tax->based_on); ?></td>    
                      <td><?php echo e($tax->is_active); ?></td>    
                      <td>
                        <?php if($tax->is_active == 1): ?>
                          <span class="text-success">Active</span>
                        <?php else: ?>
                          <span class="text-danger">Inactive</span>
                        <?php endif; ?>
                      </td>  

                      <td>
                          <div class="button-group">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permission-edit')): ?>
                            <a href="<?php echo e(route('tax.edit', $tax->id)); ?>"><i class="fa fa-pencil-square text-info"></i></a> 
                            <?php endif; ?>
                            
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('category-delete')): ?> 
                            <form id="delete-form" action="<?php echo e(route('tax.destroy', $tax->id)); ?>" method="post" style="display: inline;border:0">  
                              
                              <?php echo csrf_field(); ?>    
                              <?php echo method_field('DELETE'); ?>      
    
                              <button class="text-danger delete" type="submit" style="border:0;background:none">	  
                                <i class="fa fa-trash"></i>    
                              </button>     
                            </form> 
                            <?php endif; ?>

                          </div>    
                      </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                      <?php else: ?> 
                        <tr>
                          <td colspan="8">
                              <h3 class="text-danger">Oops! You have no permission for this action!</h3> 
                          </td>
                        </tr>
                    <?php endif; ?>
                   </tbody>
                  
                    <tfoot>
                        <tr>
                            <th>#</th>
                            <th>Tax Class</th> 
                            <th>Name</th> 
                            <th>Country</th> 
                            <th>State</th> 
                            <th>City</th>
                            <th>Zip</th> 
                            <th>Rate</th> 
                            <th>Based On</th> 
                            <th>Active</th> 
                            <th>Actions</th> 
                        </tr>
                    </tfoot> 
                  </table>
                </div>
                <!-- /.box-body -->
              </div>
              <!-- /.box -->

    </section>
    <!-- /.content -->
  </div>
<!-- /.content-wrapper -->
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('title', 'Manage Taxes'); ?>       

<?php $__env->startSection('scripts'); ?> 
<script> 
	$(document).on('click', '.delete', function(e) { 
          
          var form = $(this).parents('form:first'); 

         var confirmed = false;

           e.preventDefault();
          
           swal({
               title : 'Are you sure want to delete?',
               text : "Onec Delete, This will be permanently delete!",
               icon : "warning",
               buttons: true,
               dangerMode : true
           }).then((willDelete) => { 
               if (willDelete) {
                   // window.location.href = link;
                   confirmed = true;

               form.submit();         

               } else {
                   swal("Safe Data!");   
               }
           });
       });
</script> 
<?php $__env->stopSection(); ?> 

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/duytu/dev/dev_home/payment_visa/resources/views/admin/tax/index.blade.php ENDPATH**/ ?>