 

<?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Info Visa
        <small>Manager Info Visa</small>
      </h1>
      <ol class="breadcrumb">
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permission-write')): ?>
      <li><a href="<?php echo e(route('info_visa.list')); ?>"><i class="fa fa-users"></i>Info Visa</a></li>
      <?php endif; ?>

      <li class="active">Manager Info Visa</li>  
      </ol>
    </section> 

    <!-- Main content -->
    <section class="content container-fluid">    

      <!--------------------------
        | Your Page Content Here |
        -------------------------->
        <div class="box">
                <div class="box-header">
                  <h3 class="box-title" style="display:block">Manager Info Visa</h3>
                </div>
                <!-- /.box-header -->
                <div class="box-body">
                  <table class="table table-bordered table-responsive table-striped">
                    <thead>
                    <tr>
                      <th>#</th>
                      <th>Full name</th> 
                      <th>Email</th> 
                      <th>Date of birth</th> 
                      <th>Sex</th> 
                      <th>Current nationality</th> 
                      <th>City/Province</th>
                      <th>Purpose of entry</th> 
                      <th>Expiry date</th> 
                      <th>Create At</th> 
                      <th>Actions</th>
                    </tr>
                    </thead>

                    <tbody>
                    <?php $__currentLoopData = $infovisas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $infovisa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                      <tr>
                          <td><?php echo e($loop->index + 1); ?></td>
                          <td><?php echo e($infovisa->full_name); ?></td>  
                          <td><?php echo e($infovisa->email); ?></td>  
                          <td><?php echo e($infovisa->birthday); ?></td>  
                          <td><?php echo e($infovisa->sex); ?></td>  
                          <td><?php echo e($infovisa->nationality); ?></td>  
                          <td><?php echo e($infovisa->city_province); ?></td>  
                          <td><?php echo e($infovisa->purpose_of_entry); ?></td>  
                          <td><?php echo e($infovisa->expiry_date); ?></td>  
                          <td><?php echo e($infovisa->created_at); ?></td> 
                          <td></td>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </tbody>
                  </table>
                  <div class="row mbm">
                    <div class="col-sm-3">
                        <span class="record-total" style="text-align: right;">Tổng: <?php echo e($infovisas->total()); ?> bản
                            ghi</span>
                    </div>
                    <div class="col-sm-6 text-center">
                        <div class="pagination-panel">
                            <?php echo e($infovisas->appends(Request::all())->onEachSide(1)->links()); ?>

                        </div>
                    </div>
                    <div class="col-sm-3 text-right">
                        <span class="form-inline">
                            Hiển thị
                            <select name="per_page" class="form-control" data-target="#form-service-apartment">
                                <?php $list = [10, 20, 50, 100, 200]; ?>
                                <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $num): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($num); ?>" <?php echo e($num == @$per_page ? 'selected' : ''); ?>>
                                        <?php echo e($num); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </span>
                    </div>
                </div>
                </div>
                <!-- /.box-body -->
              </div>
              <!-- /.box -->

    </section>
    <!-- /.content -->
  </div>
<!-- /.content-wrapper -->
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('title', 'Manager Info Visa'); ?>     

<?php $__env->startSection('scripts'); ?> 
<script> 
	// $(document).on('click', '.delete', function(e) { 
          
  //         var form = $(this).parents('form:first'); 

  //        var confirmed = false;

  //          e.preventDefault();
          
  //          swal({
  //              title : 'Are you sure want to delete?',
  //              text : "Onec Delete, This will be permanently delete!",
  //              icon : "warning",
  //              buttons: true,
  //              dangerMode : true
  //          }).then((willDelete) => { 
  //              if (willDelete) {
  //                  // window.location.href = link;
  //                  confirmed = true;

  //              form.submit();         

  //              } else {
  //                  swal("Safe Data!");   
  //              }
  //          });
  //      });
</script> 
<?php $__env->stopSection(); ?> 

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/duytu/dev/dev_home/payment_visa/resources/views/admin/infovisa/list.blade.php ENDPATH**/ ?>