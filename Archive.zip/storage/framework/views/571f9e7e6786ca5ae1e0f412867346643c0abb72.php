
  <!-- Main Footer -->
  <footer class="main-footer">
    <!-- To the right -->
    <div class="pull-right hidden-xs">
        <a href="http://codershahriar.com" target="_blank">Developed by Codershahriar</a>
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; <?php echo e(date('Y')); ?> <a href="<?php echo e(url('/')); ?>"><?php echo e(config('app.name')); ?></a>.</strong> All rights reserved.
  </footer>

  <!-- Add the sidebar's background. This div must be placed
  immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->

<!-- REQUIRED JS SCRIPTS -->

<!-- jQuery 3 -->
<script src="<?php echo e(asset('wp/bower_components/jquery/dist/jquery.min.js')); ?>"></script>
<!-- Bootstrap 3.3.7 -->
<script src="<?php echo e(asset('wp/bower_components/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo e(asset('wp/dist/js/adminlte.min.js')); ?>"></script>

<!-- Optionally, plugins -->
<!-- DataTables -->
<script src="<?php echo e(asset('wp/bower_components/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('wp/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script>

<script src="<?php echo e(asset('wp/bower_components/select2/dist/js/select2.min.js')); ?>"></script>  

<!-- iCheck 1.0.1 -->
<script src="<?php echo e(asset('wp/plugins/iCheck/icheck.min.js')); ?>"></script>

<script src="<?php echo e(asset('wp/js/toastr.min.js')); ?>"></script>  
<script src="<?php echo e(asset('wp/js/sweetalert.min.js')); ?>"></script>  
<script src="<?php echo e(asset('wp/bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')); ?>"></script> 


<script>
    <?php if(Session::has('message')): ?> 
        var type = "<?php echo e(Session::get('alert-type', 'info')); ?>"; 
        switch (type) {
            case 'info' :
                toastr.info("<?php echo e(Session::get('message')); ?>");
                break; 
            case 'success' :
                toastr.success("<?php echo e(Session::get('message')); ?>");
                break; 
            case 'warning' :
                toastr.warning("<?php echo e(Session::get('message')); ?>");
                break; 
            case 'error' :
                toastr.error("<?php echo e(Session::get('message')); ?>");
                break;  
        }
    <?php endif; ?>

    $(function () {
        
        $('.select2').select2();

        $('.datatable').DataTable({ dateFormat: 'yy-mm-dd' });   

        $('.datatable2').DataTable({
        'paging'      : true,
        'lengthChange': false,
        'searching'   : true,
        'ordering'    : true,
        'info'        : true,
        'autoWidth'   : false 
        });

        //iCheck for checkbox and radio inputs
        $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
        checkboxClass: 'icheckbox_minimal-blue',
        radioClass   : 'iradio_minimal-blue' 
        });

        //Red color scheme for iCheck
        $('input[type="checkbox"].minimal-red, input[type="radio"].minimal-red').iCheck({
        checkboxClass: 'icheckbox_minimal-red',
        radioClass   : 'iradio_minimal-red'
        });

        //Flat red color scheme for iCheck
        $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
        checkboxClass: 'icheckbox_flat-green',
        radioClass   : 'iradio_flat-green'
        });
    }); 
</script>


<?php echo $__env->yieldContent('scripts'); ?>   

</body>
</html> <?php /**PATH /Users/duytu/dev/dev_home/payment_visa/resources/views/admin/layouts/footer.blade.php ENDPATH**/ ?>