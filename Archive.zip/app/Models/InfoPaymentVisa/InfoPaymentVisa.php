<?php

namespace App\Models\InfoPaymentVisa;

use Illuminate\Database\Eloquent\Model;

class InfoPaymentVisa extends Model
{
    protected $table = 'info_payments';
    protected $guarded = [];
}
